const items = document.querySelectorAll('.item');
const buttons = document.querySelectorAll('.filter-bar button');
const lightbox = document.querySelector('.lightbox');
const lightboxImg = document.querySelector('.lightbox-img');
const images = document.querySelectorAll('.item img');

let currentIndex = 0;

/* Filtering */
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    items.forEach(item => {
      item.style.display =
        filter === 'all' || item.classList.contains(filter)
        ? 'block' : 'none';
    });
  });
});

/* Lightbox */
images.forEach((img, index) => {
  img.addEventListener('click', () => {
    currentIndex = index;
    lightbox.style.display = 'flex';
    lightboxImg.src = img.src;
  });
});

document.querySelector('.close').onclick = () => {
  lightbox.style.display = 'none';
};

document.querySelector('.next').onclick = () => changeImg(1);
document.querySelector('.prev').onclick = () => changeImg(-1);

function changeImg(step) {
  currentIndex += step;
  if (currentIndex < 0) currentIndex = images.length - 1;
  if (currentIndex >= images.length) currentIndex = 0;
  lightboxImg.src = images[currentIndex].src;
}
