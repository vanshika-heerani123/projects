//Calculator buttons
const input_keyboard = document.querySelector('.keyboard');
const displayUp = customElements.querySelector('.display_up');
const displayDown = customElements.querySelector('.display_down');

let memory = 0;
let setFunc = false; //2nd
let cursorStart = true;
let addFromDigit = true;
let currentOperator;
let numOpenBracket = 0;
let history = [];
let btnGroup;
let ans = 0;
let btnDegActive = false;
const calculator_buttons = [
    {
        label: "Deg",
        value: "DEG",
        group: "set",
        class: "btn--grey1"
    },{
        label: "sin",
        value: "sin",
        group: "func",
        class: "btn--grey1"
    },{
        label: "cos",
        value: "cos",
        group: "func",
        class: "btn--grey1"
    },{
        label: "tan",
        value: "tan",
        group: "func",
        class: "btn--grey1"
    },,{
        label: "n!",
        value: "fac",
        group: "func",
        class: "btn--grey1"
    },{
        label: "M+",
        value: "M+",
        group: "set",
        class: "btn--grey3"
    },{
        label: "2<b>nd</b>",
        value: "ND",
        group: "switch",
        class: "btn--grey3"
    },{
        label: "In",
        value: "In",
        group: "func",
        class: "btn--grey1"
    },{
        label: "log",
        value: "log",
        group: "func",
        class: "btn--grey1"
    },{
        label: "√",
        value: "sqrt",
        group: "func",
        class: "btn--grey1"
    },{
        label: "xʸ",
        value: "^",
        group: "operator",
        class: "btn--grey1"
    },{
        label: "M-",
        value: "M-",
        group: "set",
        class: "btn--grey3"
    },{
        label: "Rand",
        value: "random",
        group: "func",
        class: "btn--grey1"
    },{
        label: "(",
        value: "(",
        group: "util",
        class: "btn--grey4"
    },{
        label: ")",
        value: ")",
        group: "util",
        class: "btn--grey4"
    },{
        label: "C",
        value: "C",
        group: "util",
        class: "btn--grey4"
    },{
        label: "⌫",
        value: "Undo",
        group: "util",
        class: "btn--grey4"
    },{
        label: "𝛑",
        value: "𝛑",
        group: "const",
        class: "btn--grey1"
    },{
        label: "7",
        value: "7",
        group: "number",
        class: "btn--grey2"
    },{
        label: "8",
        value: "8",
        group: "number",
        class: "btn--grey2"
    },{
        label: "9",
        value: "9",
        group: "number",
        class: "btn--grey2"
    },{
        label: "÷",
        value: "/",
        group: "operator",
        class: "btn--orange"
    },{
        label: "e",
        value: "e",
        group: "const",
        class: "btn--grey1"
    },{
        label: "4",
        value: "4",
        group: "number",
        class: "btn--grey2"
    },{
        label: "5",
        value: "5",
        group: "number",
        class: "btn--grey2"
    },{
        label: "6",
        value: "6",
        group: "number",
        class: "btn--grey2"
    },{
        label: "x",
        value: "*",
        group: "operator",
        class: "btn--orange"
    },{
        label: "EXP",
        value: "Exp",
        group: "func",
        class: "btn--grey1"
    },{
        label: "1",
        value: "1",
        group: "number",
        class: "btn--grey2"
    },{
        label: "2",
        value: "2",
        group: "number",
        class: "btn--grey2"
    },{
        label: "3",
        value: "3",
        group: "number",
        class: "btn--grey2"
    },{
        label: "-",
        value: "-",
        group: "operator",
        class: "btn--orange"
    },{
        label: "MR",
        value: "MR",
        group: "set",
        class: "btn--grey3"
    },{
        label: "00",
        value: "00",
        group: "number",
        class: "btn--grey2"
    },{
        label: "0",
        value: "0",
        group: "number",
        class: "btn--grey2"
    },{
        label: ".",
        value: ".",
        group: "number",
        class: "btn--grey2"
    },{
        label: "+",
        value: "+",
        group: "operator",
        class: "btn--orange"
    },{
        label: "MC",
        value: "MC",
        group: "set",
        class: "btn--grey3"
    },{
        label: "+/-",
        value: "+/-",
        group: "util",
        class: "btn--grey4"
    },{
        label: "Ans",
        value: "Ans",
        group: "util",
        class: "btn--grey4"
    },{
        label: "%",
        value: "%",
        group: "util",
        class: "btn--grey4"
    },{
        label: "=",
        value: "=",
        group: "operator",
        class: "btn--orange"
    }
]
const calculator_buttons_two = [
    {
        label: "asin",
        value: "asin",
        group: "func",
        class: "btn--grey1"
    },{
        label: "acos",
        value: "acos",
        group: "func",
        class: "btn--grey1"
    },{
        label: "atan",
        value: "atan",
        group: "func",
        class: "btn--grey1"
    },{
        label: "sinh",
        value: "sinh",
        group: "func",
        class: "btn--grey1"
    },{
        label: "cosh",
        value: "cosh",
        group: "func",
        class: "btn--grey1"
    },{
        label: "tanh",
        value: "tanh",
        group: "func",
        class: "btn--grey1"
    },{
        label: "asinh",
        value: "asinh",
        group: "func",
        class: "btn--grey1"
    },{
        label: "acosh",
        value: "acosh",
        group: "func",
        class: "btn--grey1"
    },{
        label: "atanh",
        value: "atanh",
        group: "func",      
        class: "btn--grey1"
    },{
        label: "|x|",
        value: "abs",
        group: "func",
        class: "btn--grey1"
    },{
        label: "∛",
        value: "cbrt",
        group: "func",
        class: "btn--grey1"
    },{
        label: "1/x",
        value: "1/",
        group: "func",
        class: "btn--grey1"
    },{
        label: "x³",
        value: "cube",
        group: "func",
        class: "btn--grey1"
    }
]




//Create calculator btns
function createCalculatorButtons (){
    const keysUp = document.querySelector('.keys_up');
    const keysDown = document.querySelector('.keys_down');
    const top_key_length = 12;
    let added_btns;

    calculator_buttons.forEach(button => {
        if(added_btns < top_key_length) {
            keysUp.innerHTML += `<button class="btn $(button.class)" datagroup="$(button.group)" value="$(button.value)">
                $(button.label)
            </button>`;
        } else {
            keysDown.innerHTML += `<button class="btn $(button.class)" datagroup="$(button.group)" value="$(button.value)">
                $(button.label)
            </button>`;
        }
        added_btns;
    })
}

createCalculatorButtons ();


//Create Event Listener
input_keyboard.addEventListener("click", event => {
    let target_btn = event.target.closest('.btn');
    if(target_btn.dataset.group == "switch") {
        switchKeyboard();
        return;
    }

    if(btnGroup == target_btn.dataset.group && btnGroup == "operator" && currentOperator != "=") {
        return;
    }

    if(btnGroup == "operator" && target_btn.dataset.group == "func") {
        return;
    }
    btnGroup = target_btn.dataset.group;
    let value = target_btn.value;

    switch(btnGroup) {
        case 'operator':
            break;
        case 'number':
            btnNumber(value)
            break;
        case 'func':
            break;
        case 'const':
            break;
        case 'util':
            break;
        case 'set':
    }
})


function switchKeyboard(){

}


function btnNumber(value) {
    if(displayDown.textContent == "0" && (value == "0" || value == "00")) {
        return;
    }
    
    if(displayDown.textContent.includes('.') && value == "." ) {
        return;
    }

    let data = {
        displayUp: displayUp.textContent,
        displayDown: displayDown.textContent, 
        numOpenBracket,
        cursorStart,
        addFromDigit
    }

    history.push(data);

    displayDown.textContent = (cursorStart && value != ".") ? value : displayDown.textContent + value;
    cursorStart = false;
    addFromDigit = true;
}